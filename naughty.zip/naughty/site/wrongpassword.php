<!DOCTYPE html>
<html lang="en">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Radio+Canada+Big:ital,wght@0,500;1,500&display=swap" rel="stylesheet">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>𝐸𝑅𝑅𝒪𝑅 𝐿𝒪𝒢𝐼𝒩 - ℕ𝔸𝕌𝔾ℍ𝕋𝕐</title>
    <style>
        body {
            font-family: "Radio Canada Big", sans-serif;
            background-color: #212121;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 400px;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.8);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(255, 255, 255, 0.1);
            color: #fff;
        }

        .error-message {
            margin-bottom: 20px;
        }

        .error-message h2 {
            margin-bottom: 20px;
            color: #ff5555;
            font-size: 28px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .error-message p {
            margin-bottom: 20px;
            color: #ffffff;
            font-size: 18px;
        }

        .back-button {
            display: inline-block;
            padding: 12px 24px;
            background-color: #3498db;
            border: none;
            border-radius: 5px;
            color: #ffffff;
            font-size: 18px;
            text-decoration: none;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .back-button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-message">
            <h2>Incorrect Login Information</h2>
            <p>Please double-check your username and password, and try again.</p>
        </div>
        <a href="/" class="back-button">Go Back</a>
    </div>
</body>
</html>
